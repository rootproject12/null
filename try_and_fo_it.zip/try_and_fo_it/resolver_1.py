import base64


text = 'Hello World!'

binary = text.encode('ascii')

encrypt = base64.b64encode(binary)

encrypt_text = encrypt.decode('ascii')

print(encrypt_text)
