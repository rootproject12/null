import base64
import hashlib
from Crypto.Cipher import AES


secret_key_life = b''

message = b''

secret_key_life = hashlib.sha256(secret_key_life).digest()

cipher = AES.new(secret_key_life, AES.MODE_ECB)

message = message + b'\0' * (AES.block_size - len(message) % AES.block_size)

encrypted = cipher.encrypt(message)

encrypted_b64 = base64.b64encode(encrypted).decode()

print('Encrypted : ', encrypted_b64)